# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['mvp1', 'mvp1.common', 'mvp1.pipeline1', 'mvp1.pipeline2', 'mvp1.utils']

package_data = \
{'': ['*'], 'mvp1': ['settings/CO/*', 'settings/MX/*']}

install_requires = \
['pydantic>=2.6.1,<3.0.0']

setup_kwargs = {
    'name': 'mvp1',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Luis Ramos',
    'author_email': 'luis.ramost@ab-inbev.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
