from enum import Enum


class countries(Enum):
    MX: str = "Mexico"
    CO: str = "Colombia"
    PE: str = "Peru"
    EC: str = "Ecuador"
