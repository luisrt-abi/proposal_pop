from pydantic import BaseModel


class settings2(BaseModel):
    country: str = "value1"
    add1: int = 1
    add2: int = 2
