from pathlib import PurePath

import yaml


class SettingsLoader:
    def __init__(self, file_path: str) -> None:
        self.file_path = file_path

    def read_yaml(self, file_name: str) -> list:
        file_path = PurePath(self.file_path, file_name)
        with open(file_path, "r") as stream:
            config = yaml.safe_load(stream)
        return config
