from pydantic import BaseModel


class settings1(BaseModel):
    country: str = "value1"
    add2: int = 2
    add3: int = 3
