from mvp1.utils.settings_loader import SettingsLoader

sl = SettingsLoader(file_path="mvp1/settings/CO")
print(sl.read_yaml(file_name="settings.yaml"))
